import { Component, OnInit } from '@angular/core';
import {Router,Route} from '@angular/router';

@Component({
  selector: 'app-login-memb-form',
  templateUrl: './login-memb-form.component.html',
  styleUrls: ['./login-memb-form.component.css']
}) 
export class LoginMembFormComponent implements OnInit {
applicant_aadhno:string="";  //ngModel value
applicant_mobno:string="";   //ngModel value
otp:string="";
entered_otp:string="";      //ngModel
isLoggedIn:boolean=false; //or true is also ok
  constructor(private router:Router) { }

  ngOnInit(): void {
    //from verify otp we get this item login cookie as true.
    let logged_status = localStorage.getItem("LoginCookie"); // kind of session 
    //LoginCookie was set as boolean value true or false as localStorage.setItem("LoginCookie","true");
    if(logged_status=="true")
    this.isLoggedIn=true;
    else
    this.isLoggedIn=false;
  }
generate_otp(){
if(this.applicant_aadhno==""){
  alert("Key in Aadhar No");
  return;
}
if(this.applicant_mobno==""){
  alert("Key in Mobile No");
  return;
}
 this.otp = Math.floor((Math.random() * 1000000) + 1).toString(); //Math.random is 0 - 0.9999999999999999. So, it generates random number between 0 1nd 1
console.log(this.otp);
}
verify_otp(){
  if(this.entered_otp==""){
    alert("Key in OTP");
    return;
  }
  if(this.entered_otp==this.otp){
    alert("Your OTP is correct. Let me take you in");
   this.isLoggedIn=true;
   localStorage.setItem("LoginCookie","true"); //localStorage.setItem is to save this data in a local browser
   localStorage.setItem("aadhar",this.applicant_aadhno);
   localStorage.setItem("mobile",this.applicant_mobno);
   localStorage.setItem("LoginRole","User"); 
   this.router.navigate(['/register']);

  }
  else{
    alert("Your OTP is incorrect. Please retry");
    return;
  }
}
logout(){
 // alert("here");
  localStorage.setItem("LoginCookie","false"); //for session
  this.isLoggedIn=false;
  this.applicant_aadhno="";
  this.applicant_mobno="";
  this.otp="";
  this.entered_otp="";
  this.router.navigate(['/']);
}

}
