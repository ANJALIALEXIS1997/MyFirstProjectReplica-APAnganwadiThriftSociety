import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginVerifyService {

  constructor() { }
  get_login_status():string{
return localStorage.getItem("LoginCookie")||"";
  }
  get_user_role():string{
    return localStorage.getItem("LoginRole")||"";
  }
}
