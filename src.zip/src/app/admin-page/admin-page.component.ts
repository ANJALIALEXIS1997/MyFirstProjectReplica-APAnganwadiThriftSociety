import { Component, OnInit,ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { AdminLoginService } from '../admin-login.service';
import {Router,Route} from '@angular/router';


@Component({
  selector: 'app-admin-page',
  templateUrl: './admin-page.component.html',
  styleUrls: ['./admin-page.component.css']
})
export class AdminPageComponent implements OnInit {
continue:boolean=false;
retrieved_pwd:string="";
admin_mobile:string="";
closeResult: string = '';
otp:string="";
entered_otp:string=""; 
new_pwd:string=""; 
conf_pwd:string=""; 
correct_otp:boolean=false;
admin_mob_no:string='';
reset_done:boolean=false;
@ViewChild('closebutton') closebutton:any=null;


  constructor(private service:AdminLoginService,private router:Router,private modalService: NgbModal) { 
   
  }

  ngOnInit(): void {
  }
  
continue_func(admin:NgForm){
  this.admin_mob_no=admin.value.mobileno
this.service.fetch_admin_details(admin.value.mobileno).subscribe(data => {
  console.log(data);
  let l = data.length;
  if(l>0){this.continue=true;
  this.retrieved_pwd=data[0].pwd;
  console.log(this.retrieved_pwd);
  localStorage.setItem("admin_mob_no",this.admin_mob_no);
  }else{
    alert("Not a Registered Mobile No for any Admin");
  }
//alert(admin.value.mobileno);
})
}
admin_login(admin:NgForm){
if(admin.value.password==this.retrieved_pwd){
  localStorage.setItem("LoginCookie","true"); 
  localStorage.setItem("LoginRole","Admin"); 
  alert("correct login");
  this.router.navigate(['/admin/payment_confirm']);
}
else{
  alert("Failed Login");
}
}
open(content:any) {
  this.otp = Math.floor((Math.random() * 1000000) + 1).toString(); //Math.random is 0 - 0.9999999999999999. So, it generates random number between 0 1nd 1
console.log(this.otp);
  this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
    this.closeResult = `Closed with: ${result}`;
  }, (reason) => {
    this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
  });
}
private getDismissReason(reason: any): string {
  if (reason === ModalDismissReasons.ESC) {
    return 'by pressing ESC';
  } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
    return 'by clicking on a backdrop';
  } else {
    return  `with: ${reason}`;
  }
}
verify_otp(){
  if(this.entered_otp==this.otp){
    this.correct_otp=true;
  }
  else{
    this.correct_otp=false;
  }
}
reset_otp(){
  this.otp = Math.floor((Math.random() * 1000000) + 1).toString(); //Math.random is 0 - 0.9999999999999999. So, it generates random number between 0 1nd 1
 this.entered_otp="";
 this.correct_otp=false;
}
reset_pwd(){
  if(this.new_pwd==this.conf_pwd){
    let data_for_insertion = {mobile_no:this.admin_mob_no,password:this.new_pwd}
    this.service.reset_password(data_for_insertion).subscribe(data => {
      console.log(data);
      alert(data.msg);
     // modal.dismiss('Cross click')
     // this.closebutton.nativeElement.click();
     // this.reset_done=true;
      location.reload();
     // this.getDismissReason("not required");
     // alert("Successfully inserted data");
  })
}
}
}