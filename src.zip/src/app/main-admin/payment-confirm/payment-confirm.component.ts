import { Component, OnInit } from '@angular/core';
import { AdminLoginService } from 'src/app/admin-login.service';

@Component({
  selector: 'app-payment-confirm',
  templateUrl: './payment-confirm.component.html',
  styleUrls: ['./payment-confirm.component.css']
})
export class PaymentConfirmComponent implements OnInit {

  pmnt_conf_retrieve_array:any[]=[]; 
  constructor(private service :AdminLoginService) { }

  ngOnInit(): void {
    this.service.admin_pmnt_confirm().subscribe(data => {
      console.log(data);
     this.pmnt_conf_retrieve_array=(data);
     console.log(this.pmnt_conf_retrieve_array);
       })
  }
payment_confirm(aadhar:string,mobile:string){
this.service.admin_pmnt_confirm_action(aadhar,mobile).subscribe(data => {
  console.log(data);
  alert(data.msg);
  this.service.admin_pmnt_confirm().subscribe(data => {
    console.log(data);
   this.pmnt_conf_retrieve_array=(data);
   console.log(this.pmnt_conf_retrieve_array);
     })
   })
}
}
