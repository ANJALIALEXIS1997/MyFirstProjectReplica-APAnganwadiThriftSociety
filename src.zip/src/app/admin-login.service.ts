import { Injectable } from '@angular/core';
import { throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { HttpClient, HttpHeaders, HttpErrorResponse } from
  '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class AdminLoginService {
  private httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };
  constructor(private httpClient: HttpClient) { }
  private httpErrorHandler(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      console.error("A client side error occurs. The error message is " + error.message);
    } else {
      console.error(
        "An error happened in server. The HTTP status code is " + error.status + " and the error returned is " + error.message);
    }

    return throwError("Error occurred. Pleas try again");
  }
  fetch_admin_details(mobno:string): Observable<any> {
    let data_pass={mobno_key:mobno}
    return this.httpClient.post<any>("http://localhost:8080/get_admin_details",data_pass)
      .pipe(
        retry(7),
        catchError(this.httpErrorHandler)
      );
  }
  reset_password(data_pass:any):Observable<any>{
    return this.httpClient.post<any>("http://localhost:8080/password_reset",data_pass)
      .pipe(
        retry(7),
        catchError(this.httpErrorHandler)
      );
  }
  //payment confirmation in admin data fetching starting line 
  admin_pmnt_confirm():Observable<any>{
    return this.httpClient.post<any>("http://localhost:8080/pmnt_confirm_admin",'')
      .pipe(
        retry(7),
        catchError(this.httpErrorHandler)
      );
  }
  //end line of data fetch
  // who confirmed the payment is being done . Which admin confirmed based on aadhar and mobile no we find out
  admin_pmnt_confirm_action(aadhar:string,mobile:string):Observable<any>{
    let admin_mobile:string=localStorage.getItem("admin_mob_no")||"";
    let data_to_pass={aadhar:aadhar,mobile:mobile,admin_mobile:admin_mobile};
    return this.httpClient.post<any>("http://localhost:8080/pmnt_confirm_admin_action",data_to_pass)
      .pipe(
        retry(7),
        catchError(this.httpErrorHandler)
      );
  }
  //
  //district-wise-confirm
  dist_wise_confirm():Observable<any>{
    return this.httpClient.post<any>("http://localhost:8080/dist_wise_confirm_admin",'')
    .pipe(
      retry(7),
      catchError(this.httpErrorHandler)
    );
  }
  //
  //district-wise-confirmation-done by-which mobileno and aadhar no.
  dist_wise_confirm_action(aadhar:string,mobile:string):Observable<any>{
    let admin_mobile:string=localStorage.getItem("admin_mob_no")||"";
    let data_to_pass={aadhar:aadhar,mobile:mobile,admin_mobile:admin_mobile};
    return this.httpClient.post<any>("http://localhost:8080/dist_wise_confirm_admin_action",data_to_pass)
      .pipe(
        retry(7),
        catchError(this.httpErrorHandler)
      );
  }
  //
  // glno to be generated after we fetch the data from server to client.
  gl_generate():Observable<any>{
    return this.httpClient.post<any>("http://localhost:8080/glno_generate_admin",'')
    .pipe(
      retry(7),
      catchError(this.httpErrorHandler)
    );
  }
  gl_generate_action(aadhar:string,mobile:string,admin_mobile:string):Observable<any>{
    let data_to_pass={aadhar:aadhar,mobile:mobile,admin_mobile:admin_mobile}
    return this.httpClient.post<any>("http://localhost:8080/glno_generate_admin_action",data_to_pass)
    .pipe(
      retry(7),
      catchError(this.httpErrorHandler)
    );
  }
  //
}
